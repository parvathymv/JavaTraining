package com.behavioural.chainofresp;

abstract class Logger {
    protected Logger nextLogger;

    public void setNextLogger(Logger nextLogger) {
        this.nextLogger = nextLogger;
    }

    public void logMessage(int level, String message) {
        if (this.canHandle(level)) {
            write(message);
        }
        
        if (nextLogger != null) {
            nextLogger.logMessage(level, message);
        }
    }

    protected abstract boolean canHandle(int level);

    protected abstract void write(String message);
}

class InfoLogger extends Logger {
    @Override
    protected boolean canHandle(int level) {
        return level == 1;
    }

    @Override
    protected void write(String message) {
        System.out.println("INFO: " + message);
    }
}

class DebugLogger extends Logger {
    @Override
    protected boolean canHandle(int level) {
        return level == 2;
    }

    @Override
    protected void write(String message) {
        System.out.println("DEBUG: " + message);
    }
}

class ErrorLogger extends Logger {
    @Override
    protected boolean canHandle(int level) {
        return level == 3;
    }

    @Override
    protected void write(String message) {
        System.out.println("ERROR: " + message);
    }
}

public class ChainOfResponsibility{
    private static Logger createLoggerChain() {
        Logger errorLogger = new ErrorLogger();
        Logger debugLogger = new DebugLogger();
        Logger infoLogger = new InfoLogger();

        infoLogger.setNextLogger(debugLogger);
        debugLogger.setNextLogger(errorLogger);

        return infoLogger;
    }

    public static void main(String[] args) {
        Logger loggerChain = createLoggerChain();

        loggerChain.logMessage(1, "This is an informational message.");
        loggerChain.logMessage(2, "This is a debug-level message.");
        loggerChain.logMessage(3, "This is an error message.");
    }
}


