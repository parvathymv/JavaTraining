package com.creational.abstractfactory;

public class Samsung {

}
