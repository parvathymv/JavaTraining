package com.creational.abstractfactory;

public class Lenovo {
public void pictureCapacity()
{}
}
