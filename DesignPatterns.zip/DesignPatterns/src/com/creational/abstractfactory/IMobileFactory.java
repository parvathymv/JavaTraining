package com.creational.abstractfactory;


public interface IMobileFactory {

	IMobileFactory createMobile(String type);
}
