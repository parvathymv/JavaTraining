package com.creational.abstractfactory;

public class SamsungMobileFactory extends MobileFactory {

    Samsung createSamsungMobile(){
       return new Samsung();
    }
}
