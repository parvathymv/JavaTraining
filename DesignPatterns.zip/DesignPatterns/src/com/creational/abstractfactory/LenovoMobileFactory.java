package com.creational.abstractfactory;

public class LenovoMobileFactory extends MobileFactory {

    Lenovo createLenovoMobile(){
      return new Lenovo();
    }
}
