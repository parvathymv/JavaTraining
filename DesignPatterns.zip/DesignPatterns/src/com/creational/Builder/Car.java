package com.creational.Builder;

class Car {
    // Required parameters
    private final String engine;
    private final int wheels;

    // Optional parameters
    private final boolean airbags;
    private final boolean sunroof;

    private Car(Builder builder) {
        this.engine = builder.engine;
        this.wheels = builder.wheels;
        this.airbags = builder.airbags;
        this.sunroof = builder.sunroof;
    }

    // Static nested Builder class
    public static class Builder {
        // Required parameters
        private final String engine;
        private final int wheels;

        // Optional parameters - initialized to default values
        private boolean airbags = false;
        private boolean sunroof = false;

        // Constructor for required parameters
        public Builder(String engine, int wheels) {
            this.engine = engine;
            this.wheels = wheels;
        }

        // Methods for optional parameters
        public Builder setAirbags(boolean airbags) {
            this.airbags = airbags;
            return this;
        }

        public Builder setSunroof(boolean sunroof) {
            this.sunroof = sunroof;
            return this;
        }

        // Build method to construct the Car object
        public Car build() {
            return new Car(this);
        }
    }

    @Override
    public String toString() {
        return "Car [engine=" + engine + ", wheels=" + wheels + 
               ", airbags=" + airbags + ", sunroof=" + sunroof + "]";
    }
}
//Builder -static inner class
// Usage
class Main {
    public static void main(String[] args) {
        Car car = new Car.Builder("V6", 4)
                .setAirbags(true)
                .setSunroof(true)
                .build();
//Builder b=new Builder();
        System.out.println(car);
    }
}

