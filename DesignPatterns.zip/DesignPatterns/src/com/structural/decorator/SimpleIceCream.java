package com.structural.decorator;

public class SimpleIceCream implements Icecream {
	 @Override
     public String makeIcecream() {

         return "Base-Icecream ";
     }
}
