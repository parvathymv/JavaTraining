package com.structural.decorator;

public class DecoratorPatternDemo {

    public static void main(String[] args) {

       Icecream icecream = new HoneyDecorator(new NuttyDecorator(new SimpleIceCream()));
       System.out.println(icecream.makeIcecream());
    }
}
