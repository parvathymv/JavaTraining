package com.structural.facade;

//Subsystem classes
class DVDPlayer {
	public void on() {
		System.out.println("DVD Player is ON");
	}

	public void play(String movie) {
		System.out.println("Playing movie: " + movie);
	}

	public void off() {
		System.out.println("DVD Player is OFF");
	}
}

class Projector {
	public void on() {
		System.out.println("Projector is ON");
	}

	public void setWideScreenMode() {
		System.out.println("Projector is set to widescreen mode");
	}

	public void off() {
		System.out.println("Projector is OFF");
	}
}

class Lights {
	public void dim(int level) {
		System.out.println("Lights dimmed to " + level + "%");
	}
}

//Facade class
class HomeTheaterFacade {
	private DVDPlayer dvdPlayer;
	private Projector projector;
	private Lights lights;

	public HomeTheaterFacade(DVDPlayer dvdPlayer, Projector projector, Lights lights) {
		this.dvdPlayer = dvdPlayer;
		this.projector = projector;
		this.lights = lights;
	}

	public void watchMovie(String movie) {
		System.out.println("Preparing to watch a movie...");
		lights.dim(10);
		projector.on();
		projector.setWideScreenMode();
		dvdPlayer.on();
		dvdPlayer.play(movie);
	}

	public void endMovie() {
		System.out.println("Shutting down the home theater...");
		lights.dim(100);
		projector.off();
		dvdPlayer.off();
	}
}

//Client code
public class FacadeDemo {
	public static void main(String[] args) {
		DVDPlayer dvdPlayer = new DVDPlayer();
		Projector projector = new Projector();
		Lights lights = new Lights();

		HomeTheaterFacade homeTheater = new HomeTheaterFacade(dvdPlayer, projector, lights);

		homeTheater.watchMovie("Inception");
		homeTheater.endMovie();
	}
}
