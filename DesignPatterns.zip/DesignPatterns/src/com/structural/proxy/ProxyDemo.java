package com.structural.proxy;

//Subject
interface Image {
 void display();
}

//Real Subject
class RealImage implements Image {
 private String filename;

 public RealImage(String filename) {
     this.filename = filename;
     loadImage();
 }

 private void loadImage() {
     System.out.println("Loading " + filename);
 }

 @Override
 public void display() {
     System.out.println("Displaying " + filename);
 }
}

//Proxy
class ImageProxy implements Image {
 private String filename;
 private RealImage realImage;

 public ImageProxy(String filename) {
     this.filename = filename;
 }

 @Override
 public void display() {
     if (realImage == null) {
         realImage = new RealImage(filename); // Lazy initialization
     }
     realImage.display();
 }
}

//Client
public class ProxyDemo {
 public static void main(String[] args) {
     Image image = new ImageProxy("photo.jpg");
     image.display(); // Loads and displays the image
     image.display(); // Only displays the image
 }
}

