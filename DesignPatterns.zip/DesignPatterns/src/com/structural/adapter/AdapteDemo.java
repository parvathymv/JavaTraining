package com.structural.adapter;

public class AdapteDemo {
	public static void main(String[] atgs)
	{
	 Apple apple = new Apple();
     apple.getAppleColor("green");

     Orange orange = new Orange();
     Appleadapter adapter = new Appleadapter(orange);
     adapter.getAppleColor("red");
}
}
