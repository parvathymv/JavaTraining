package com.structural.adapter;

public class Apple {

    public void getAppleColor(String color){
       System.out.println("Apple color is : " +color);
    }
}
