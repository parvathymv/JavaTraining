package com.structural.adapter;

public class Orange {

    public void getOrangeColor(String color){
       System.out.println("Orange color is : " +color);
    }
}
