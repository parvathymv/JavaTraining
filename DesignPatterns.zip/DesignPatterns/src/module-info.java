/**
 * 
 */
/**
 * 
 */
module DesignPatterns {
}