package com.demo.elk.elkproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ElkprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
